# load packages
library(epm)
library(rgdal)
library(sf)
library(caper)
library(geiger)
library(letsR)
library(ggplot2)
library(spdep)
library(spatialreg)
library(rnaturalearth)
library(picante)

#load world map
world <- ne_countries(scale = "medium", returnclass = "sf")


##Rapoport's rule in birds of the Iciteridae family

#load the data
ict<-read.csv("data/ict.csv",header=T) 

#see the data
head(ict)

#clean the data
ict<-na.omit(ict) #remove entries with NA values
ict<-unique(ict) #remove repeated data
names(ict)<-c("taxon","x","y") #renames columns
ict$taxon<-gsub(" ","_",ict$taxon)# pattern substitution

#look data agaoin
head(ict)

#lets see the data in the mao
ggplot()+
  geom_sf(data=world,fill="#3C3C3C",color="#3C3C3C")+#plots world
  geom_point(data=ict,aes(x=x,y=y),color="darkred")+#plots data points
  theme_void()#removes graphic desing

##The presence-absence matrix
presab<-lets.presab.points(cbind(ict$x,ict$y),ict$taxon,resol = 1)# lets.presab creates a presence absence matrix using coordinates and names

#a look into the PAM structure
presab$Presence_and_Absence_Matrix[1:10,1:7]

#a look into the PAM in the geography
plot(presab)

## Range size
ranges<-lets.rangesize(presab,units = "squaremeter",coordinates = "planar")# obtains ranges in square meters
ranges<-ranges/(1000^2) #conver to square kilometers
ict_rap<-data.frame(species=presab$Species_name,range_size=ranges) #combine species names with their range size

#lets see the species' ranges in sqKm
head(ict_rap)

##Latitudinal mid point

midp<-lets.midpoint(presab) #calculates the latitudinal midpoint of species ranges
ict_rap<-data.frame(ict_rap,latitude=midp$y)# now we add to our species-range size data.frame the latitudinal mid point

#lets see it
head(ict_rap)


## Rapoport's rule
rap_model<-lm(log(Range_size)~abs(latitude),data=ict_rap)#simple linear model
summary(rap_model)#summary of the model

#lets see the relationship
p<-ggplot(ict_rap,aes(abs(latitude),log(Range_size)))+
  geom_point(color="black")+
  xlab("absolute latitude")+
  ylab("Log (Range size)")+
  geom_smooth(method= lm , color="red", fill="#69b3a2", se=TRUE)+
  theme_classic()
plot(p)


#Now lets account for phylogenetic non-indepedence

#laod the phylogenetic data
tre<-read.tree("data/Icteridae_tree.txt")
#look at it
tre
plot(tre,show.tip.label=F)
#match the phylogenetic data with the map data
compict<-comparative.data(tre,data=ict_rap,names.col = "species",vcv = T)
compict

#fit a Phylogenetic General Least Squares (PGLS) model
raprule<-pgls(log(Range_size)~abs(latitude),data=compict,lambda="ML")
summary(raprule)

#What is the difference?


##Community approach

#lets just keep the communities extracting the coordinates
matx<-data.frame(presab$Presence_and_Absence_Matrix[,-c(1,2)])
head(matx)
#save the coordinates in a different object
coords<-presab$Presence_and_Absence_Matrix[,c(1,2)]
head(coords)

#create ids for each pair of coordinates
coordsid<-data.frame(x=coords[,1],y=coords[,2],id=1:length(coords[,1]))
head(coordsid)



#calculate spcies richness
sr<-rowSums(matx)
ldg<-data.frame(coordsid,sr)
head(ldg)

#Now we can test it
ldgmodel<-lm(sr~abs(y),data=ldg)
summary(ldgmodel)


#PD
#match species in geography with species in phylogeny
matchphylo<-match.phylo.comm(tre,matx)

#calculate pd
ictpd<-pd(matchphylo$comm,matchphylo$phy)


#join them with coordinates
pdldg<-data.frame(coordsid,ictpd)
head(pdldg)

#test it with a model
pdmodel<-lm(PD~abs(y),data=pdldg)
summary(pdmodel)

#and see it
p2<-ggplot(pdldg,aes(abs(y),PD))+
geom_point(color="black")+
  geom_smooth(method= lm , color="red", fill="#69b3a2", se=TRUE) +
  xlab("absolute latitude")+
  theme_classic()
plot(p2)


##Accounting for spatial non-independence

#tranforming points into spatial points
pdldg<-na.omit(pdldg)
pdldg.sp<-st_as_sf(pdldg,coords=c("x","y"),crs=st_crs(presab$Richness_Raster))

#creat a list of spatial variance/covariance
near<-knearneigh(pdldg.sp,k=8) #gets the neighbors for each point
nbr<-knn2nb(near) #creates a distance matrix with said neighbors
tw<-nb2listw(nbr) #creates a list of spatial covariance weight

#run spatially explicit model
spatialmodel<-errorsarlm(formula=PD~abs(y),data=pdldg,listw=tw)
summary(spatialmodel, Nagelkerke=T)

