library(ape)
library(phangorn)
library(phytools)
#vibrios

# 0. Aligment
dna<-readDNAStringSet("https://raw.githubusercontent.com/AxelArango/phyloclass/refs/heads/main/datasets/vibrio.fna",format = "fasta")
dna_align<-muscle(dna)
dna_align <-as(dna_align, "DNAStringSet")
writeXStringSet(dna_align, file="vibrio_a.fna")

# 1. ML analysis
dna <- read.dna("vibrio_a.fna", format = "fasta")
phy_data <- phyDat(dna, type = "DNA")
start_tree <- nj(dist.dna(dna, model = "K80"))
fit_init <- pml(start_tree, phy_data)
fit_gtr <- optim.pml(fit_init, model = "GTR", 
                     optGamma = TRUE, 
                     rearrangement = "NNI")

# 2. Bootstrap the ML tree (this takes time!)
boot_ml <- bootstrap.pml(fit_gtr, bs = 1000, 
                         optNni = TRUE,
                         multicore = TRUE,
                         mc.cores = 7)

# 2.5 selected tree
cons_tree<-midpoint(fit_gtr$tree)
plot(cons_tree)
#cons_tree$tip.label<-vibrios
#
mcc_tree<-mcc(boot_ml)
# 3. Root your best tree or the consensus
rooted_tree <- root(mcc_tree, 
                    outgroup = "Alivibrio_fischeri",  
                    resolve.root = TRUE)

# 4. Make ultrametric/dated
dated_tree <- chronos(rooted_tree, 
                      lambda = 1,
                      model = "relaxed",
                      quiet = FALSE)

# Check it worked
is.ultrametric(dated_tree)

# 5. Calculate bootstrap support for the dated tree
# This matches clades in dated_tree to clades in bootstrap replicates
boot_support <- prop.clades(dated_tree, boot_ml)/1000
boot_support
#boot_support2<-boot_support[-1]
#dated_tree2<-drop.tip(dated_tree,"Alivibrio_fischeri")
# 6. Visualize
plot(dated_tree, cex = 0.8, main = "Time-Calibrated Phylogeny")
nodelabels(boot_support, cex = 0.6, bg = "lightblue", 
           frame = "circle")
axisPhylo()  # Add time axis
mtext("Time (substitutions/site)", side = 1, line = 2)
#

# 7. Save
dated_tree$node.label <- boot_support
write.tree(dated_tree, "final_tree.tre")

#
tree<-read.tree("final_tree.tre")

plot(tree, cex = 0.8, main = "Time-Calibrated Phylogeny")

nodelabels(tree$node.label, cex = 0.6, bg = "lightblue", 
           frame = "circle")
